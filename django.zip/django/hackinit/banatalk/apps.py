from django.apps import AppConfig


class BanatalkConfig(AppConfig):
    name = 'banatalk'
