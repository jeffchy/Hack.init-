
export interface IDetachable {
    Detach(): void;
}
